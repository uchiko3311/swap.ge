module Api::UniversitiesHelper
end
