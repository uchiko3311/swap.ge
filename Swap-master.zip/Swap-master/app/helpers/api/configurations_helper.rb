module Api::ConfigurationsHelper
end
